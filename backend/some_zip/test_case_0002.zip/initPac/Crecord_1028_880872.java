package initPac;
public record Crecord_1028_880872(java.lang.String name, int age) {
    public void printLocationMethod_1028_85f49a() {
        java.lang.System.out.println("Crecord_1028_880872 printLocationMethod_1028_85f49a");
    }

    public void printInfo() {
        initPac.P_1028_484b58.Ce_1028_628134 ce_1028_628134_1028_71b78d = initPac.P_1028_484b58.Ce_1028_628134.VALUE2;
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
