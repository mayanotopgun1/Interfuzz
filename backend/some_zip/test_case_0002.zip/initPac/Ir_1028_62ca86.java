package initPac;
public interface Ir_1028_62ca86 {
    void run_1028_ac493e();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_62ca86: default method");
    }
}
