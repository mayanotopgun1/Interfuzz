package initPac;
public enum Ce_1028_e0eaac {

    VALUE1,
    VALUE2;

    int[] field_1028_fed334;
}
