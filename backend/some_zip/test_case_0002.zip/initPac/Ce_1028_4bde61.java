package initPac;
public enum Ce_1028_4bde61 {

    VALUE1,
    VALUE2;
}
