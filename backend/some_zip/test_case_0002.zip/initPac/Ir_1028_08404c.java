package initPac;
public interface Ir_1028_08404c {
    void run_1028_f33d07();

    default void defaultMethod() {
        initPac.Test0002 test0002_1028_91f9f1 = new initPac.Test0002();
        java.lang.System.out.println("Ir_1028_08404c: default method");
    }
}
