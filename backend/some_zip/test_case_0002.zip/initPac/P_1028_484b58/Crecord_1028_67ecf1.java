package initPac.P_1028_484b58;
public record Crecord_1028_67ecf1(java.lang.String name, int age) {
    public void printLocationMethod_1028_75fe6b() {
        java.lang.System.out.println("Crecord_1028_67ecf1 printLocationMethod_1028_75fe6b");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
