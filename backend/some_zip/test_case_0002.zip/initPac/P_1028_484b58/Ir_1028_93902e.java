package initPac.P_1028_484b58;
public interface Ir_1028_93902e {
    void run_1028_1824c3();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_93902e: default method");
    }
}
