package initPac.P_1028_484b58;
public interface If_1028_1c2da3 {
    abstract int apply_1028_cc5f42();
}
