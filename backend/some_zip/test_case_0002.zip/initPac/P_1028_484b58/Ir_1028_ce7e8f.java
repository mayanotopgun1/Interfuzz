package initPac.P_1028_484b58;
public interface Ir_1028_ce7e8f {
    void run_1028_83f6bb();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_ce7e8f: default method");
    }
}
