package initPac.P_1028_484b58;
public record Crecord_1028_241ed6(java.lang.String name, int age) {
    public void printLocationMethod_1028_512977() {
        java.lang.System.out.println("Crecord_1028_241ed6 printLocationMethod_1028_512977");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
