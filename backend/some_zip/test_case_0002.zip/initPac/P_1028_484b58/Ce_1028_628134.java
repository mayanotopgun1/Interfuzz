package initPac.P_1028_484b58;
public enum Ce_1028_628134 {

    VALUE1,
    VALUE2;
}
