package initPac.P_1028_484b58;
public interface If_1028_f2e2b2 {
    abstract int apply_1028_4edf56();
}
