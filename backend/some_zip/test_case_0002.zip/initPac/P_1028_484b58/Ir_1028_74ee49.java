package initPac.P_1028_484b58;
public interface Ir_1028_74ee49 {
    void run_1028_9cf7c8();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_74ee49: default method");
    }
}
