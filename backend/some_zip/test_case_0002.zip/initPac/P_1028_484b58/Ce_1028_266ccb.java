package initPac.P_1028_484b58;
public enum Ce_1028_266ccb {

    VALUE1,
    VALUE2;

    public void printLocationMethod_1028_8a1381() {
        java.lang.System.out.println("initPac.P_1028_484b58.Ce_1028_266ccb printLocationMethod_1028_8a1381");
    }

    public void printLocationMethod_1028_d128c3() {
        java.lang.System.out.println("initPac.P_1028_484b58.Ce_1028_266ccb printLocationMethod_1028_d128c3");
    }

    public void printLocationMethod_1028_f222b1() {
        java.lang.System.out.println("initPac.P_1028_484b58.Ce_1028_266ccb printLocationMethod_1028_f222b1");
    }
}
