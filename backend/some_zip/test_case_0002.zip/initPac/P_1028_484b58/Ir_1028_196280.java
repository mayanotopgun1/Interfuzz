package initPac.P_1028_484b58;
public interface Ir_1028_196280 {
    void run_1028_1f0136();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_196280: default method");
    }
}
