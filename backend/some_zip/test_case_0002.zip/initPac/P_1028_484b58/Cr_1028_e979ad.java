package initPac.P_1028_484b58;
public class Cr_1028_e979ad extends initPac.Test0002 {
    public void printLocationMethod_1028_3c8b18() {
        java.lang.System.out.println("Cr_1028_e979ad printLocationMethod_1028_3c8b18");
    }

    public void printLocationMethod_1028_c9b542() {
        java.lang.System.out.println("initPac.P_1028_484b58.Cr_1028_e979ad printLocationMethod_1028_c9b542");
    }

    public void printLocationMethod_1028_b6de1a() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_780641) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void vMeth() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_fffe78) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_392794() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_0acddb) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_77a29a() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_a10017) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_b73e3b() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_79c322) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8e1c9d() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_901ea8) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void mainTest(java.lang.String[] strArr1) {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_dd7ef4) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_f5b142() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_387351) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void vMeth1(long l) {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_594451) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public int iMeth() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_60553e) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int int_1028_14200d = 1;
        return int_1028_14200d;
    }

    public void printLocationMethod_1028_4f9359() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_38802e) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8acf75() {
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_ae4b20) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_eaed59() {
        initPac.P_1028_484b58.Cg_1028_25a618 cg_1028_25a618_1028_8cacbf = new initPac.P_1028_484b58.Cg_1028_25a618();
        this.field_1028_b121de = cg_1028_25a618_1028_8cacbf;
        try {
            printLocationMethod_1028_c9b542();
        } catch (java.lang.Exception e1028_fd79c9) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_c9b542");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_5c18ec() {
        java.lang.System.out.println("initPac.P_1028_484b58.Cr_1028_e979ad printLocationMethod_1028_5c18ec");
    }

    public initPac.P_1028_484b58.Cg_1028_25a618 field_1028_b121de;

    public char[] field_1028_78eedc;
}
