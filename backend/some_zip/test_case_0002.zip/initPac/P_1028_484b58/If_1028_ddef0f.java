package initPac.P_1028_484b58;
public interface If_1028_ddef0f {
    abstract int apply_1028_315e67();
}
