package initPac.P_1028_484b58;
public record Crecord_1028_98f019(java.lang.String name, int age) {
    public void printLocationMethod_1028_167134() {
        java.lang.System.out.println("Crecord_1028_98f019 printLocationMethod_1028_167134");
    }

    public void printInfo() {
        try {
            java.lang.String string_1028_d01947 = "123456abc";
            int int_1028_a6c63d = 70;
            initPac.Crecord_1028_880872 crecord_1028_880872_1028_3a8723 = new initPac.Crecord_1028_880872(string_1028_d01947, int_1028_a6c63d);
            crecord_1028_880872_1028_3a8723.name();
        } catch (java.lang.Exception e1028_5ef2fd) {
            java.lang.System.out.println("Method Invoke Exception: name");
        }
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }

    public void printLocationMethod_1028_384924() {
        java.lang.System.out.println("initPac.P_1028_484b58.Crecord_1028_98f019 printLocationMethod_1028_384924");
    }
}
