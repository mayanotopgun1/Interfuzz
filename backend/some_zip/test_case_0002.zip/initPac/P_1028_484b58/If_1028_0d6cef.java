package initPac.P_1028_484b58;
public interface If_1028_0d6cef extends initPac.P_1028_484b58.If_1028_ddef0f {
    abstract int apply_1028_51df94();
}
