package initPac.P_1028_484b58;
public record Crecord_1028_ae7264(java.lang.String name, int age) {
    public void printLocationMethod_1028_3a9788() {
        java.lang.System.out.println("Crecord_1028_ae7264 printLocationMethod_1028_3a9788");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
