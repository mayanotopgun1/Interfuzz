package initPac.P_1028_484b58;
public class Cr_1028_d4f594 extends initPac.P_1028_484b58.Cr_1028_e979ad {
    public void printLocationMethod_1028_99eb77() {
        java.lang.System.out.println("Cr_1028_d4f594 printLocationMethod_1028_99eb77");
    }

    public void printLocationMethod_1028_cdd7e0() {
        java.lang.System.out.println("initPac.P_1028_484b58.Cr_1028_d4f594 printLocationMethod_1028_cdd7e0");
    }

    public void printLocationMethod_1028_b6de1a() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_9418d4) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void vMeth() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_464858) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_c9b542() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_51c671) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_392794() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_8024d8) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_77a29a() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_8630da) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_b73e3b() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_f85ec2) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8e1c9d() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_e1cf64) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void mainTest(java.lang.String[] strArr1) {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_b31689) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_f5b142() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_82bc88) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_3c8b18() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_737d2e) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void vMeth1(long l) {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_7c0308) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public int iMeth() {
        int int_1028_6081cb = 58;
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_8aa7f4) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        return int_1028_6081cb;
    }

    public void printLocationMethod_1028_4f9359() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_5c32a2) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8acf75() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_3feb58) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_eaed59() {
        try {
            printLocationMethod_1028_cdd7e0();
        } catch (java.lang.Exception e1028_bee549) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_cdd7e0");
        }
        int a = 123;
    }

    public initPac.If_1028_356365 field_1028_475919;

    public initPac.Ce_1028_c9b13a[] field_1028_8fe23b;

    public initPac.P_1028_d0192f.Crecord_1028_38fbc7[] field_1028_73412a;

    initPac.P_1028_a42518.Ce_1028_1a1d8f[] field_1028_57d836;
}
