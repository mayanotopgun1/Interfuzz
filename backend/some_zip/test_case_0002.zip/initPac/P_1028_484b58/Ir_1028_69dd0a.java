package initPac.P_1028_484b58;
public interface Ir_1028_69dd0a {
    void run_1028_df8b83();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_69dd0a: default method");
    }
}
