package initPac.P_1028_484b58;
public interface Ir_1028_0308f4 {
    void run_1028_83ba6b();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_0308f4: default method");
    }
}
