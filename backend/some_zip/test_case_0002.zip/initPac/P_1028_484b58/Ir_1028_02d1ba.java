package initPac.P_1028_484b58;
public interface Ir_1028_02d1ba extends initPac.Ir_1028_83db60 {
    void run_1028_179948();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_02d1ba: default method");
    }
}
