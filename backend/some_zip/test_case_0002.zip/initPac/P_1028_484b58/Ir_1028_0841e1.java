package initPac.P_1028_484b58;
public interface Ir_1028_0841e1 {
    void run_1028_8bc7fb();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_0841e1: default method");
    }
}
