package initPac.P_1028_484b58;
public interface If_1028_10704f extends initPac.Ir_1028_fd5070 {
    abstract int apply_1028_274df3();
}
