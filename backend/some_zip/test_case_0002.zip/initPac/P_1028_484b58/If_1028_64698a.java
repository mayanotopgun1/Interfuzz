package initPac.P_1028_484b58;
public interface If_1028_64698a {
    abstract int apply_1028_5ae092();
}
