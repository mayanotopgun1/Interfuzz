package initPac.P_1028_484b58;
public class Cg_1028_25a618<T> extends initPac.Test0002 implements initPac.P_1028_484b58.Ir_1028_74ee49 {
    public void run_1028_9cf7c8() {
    }

    java.util.List<T> items_1028_2d3e91 = new java.util.ArrayList<T>();

    public void addItem_1028_6379fe(T item) {
        this.items_1028_2d3e91.add(item);
    }

    public T getItem_1028_f762ed(int index) {
        if (this.items_1028_2d3e91.isEmpty()) {
            return null;
        }
        int size = this.items_1028_2d3e91.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_2d3e91.get(idx);
    }

    T value_1028_dffa56;

    public T getValue_1028_dffa56() {
        return this.value_1028_dffa56;
    }

    public void setValue_1028_dffa56(T value) {
        this.value_1028_dffa56 = value;
    }

    public void printLocationMethod_1028_02ddf0() {
        java.lang.System.out.println("Cg_1028_25a618 printLocationMethod_1028_02ddf0");
    }

    public void printLocationMethod_1028_942805() {
        java.lang.System.out.println("initPac.P_1028_484b58.Cg_1028_25a618 printLocationMethod_1028_942805");
    }

    public void vMeth() {
        initPac.Ce_1028_3589b5 ce_1028_3589b5_1028_78c39f = initPac.Ce_1028_3589b5.VALUE2;
        this.field_1028_bd196e = ce_1028_3589b5_1028_78c39f;
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String> cg_1028_25a618_1028_fc8fd7 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String>();
            cg_1028_25a618_1028_fc8fd7.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_8aa99c) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8e1c9d() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer[]> cg_1028_25a618_1028_7fc4a4 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer[]>();
            cg_1028_25a618_1028_7fc4a4.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_289fb7) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void mainTest(java.lang.String[] strArr1) {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer> cg_1028_25a618_1028_717ff4 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer>();
            cg_1028_25a618_1028_717ff4.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_d8f584) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_f5b142() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer> cg_1028_25a618_1028_043108 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer>();
            cg_1028_25a618_1028_043108.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_257427) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        initPac.P_1028_484b58.Cg_1028_25a618 cg_1028_25a618_1028_9666b4 = new initPac.P_1028_484b58.Cg_1028_25a618();
        this.field_1028_03dc80 = cg_1028_25a618_1028_9666b4;
        int a = 123;
    }

    public void printLocationMethod_1028_392794() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String[]> cg_1028_25a618_1028_01edaf = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String[]>();
            cg_1028_25a618_1028_01edaf.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_65402e) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_77a29a() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String[]> cg_1028_25a618_1028_4dd999 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String[]>();
            cg_1028_25a618_1028_4dd999.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_6f27a7) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void vMeth1(long l) {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer> cg_1028_25a618_1028_832de6 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Integer>();
            cg_1028_25a618_1028_832de6.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_cb0615) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_b73e3b() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String> cg_1028_25a618_1028_947e09 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.String>();
            cg_1028_25a618_1028_947e09.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_5a6755) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public int iMeth() {
        int int_1028_e4b8cb = 22;
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Byte> cg_1028_25a618_1028_fa50d8 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Byte>();
            cg_1028_25a618_1028_fa50d8.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_536e64) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        return int_1028_e4b8cb;
    }

    public void printLocationMethod_1028_4f9359() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Short[]> cg_1028_25a618_1028_b1e700 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Short[]>();
            cg_1028_25a618_1028_b1e700.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_21012f) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8acf75() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Short[]> cg_1028_25a618_1028_608054 = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Short[]>();
            cg_1028_25a618_1028_608054.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_1b5147) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_eaed59() {
        try {
            initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Short> cg_1028_25a618_1028_1915ad = new initPac.P_1028_484b58.Cg_1028_25a618<java.lang.Short>();
            cg_1028_25a618_1028_1915ad.printLocationMethod_1028_942805();
        } catch (java.lang.Exception e1028_467745) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_942805");
        }
        int a = 123;
    }

    public initPac.P_1028_484b58.Cg_1028_25a618 field_1028_03dc80;

    public initPac.Ce_1028_3589b5 field_1028_bd196e;
}
