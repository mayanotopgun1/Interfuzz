package initPac;
public record Crecord_1028_23ef60(java.lang.String name, int age) {
    public void printLocationMethod_1028_410a91() {
        java.lang.System.out.println("Crecord_1028_23ef60 printLocationMethod_1028_410a91");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }

    public void printLocationMethod_1028_b12e22() {
        java.lang.System.out.println("initPac.Crecord_1028_23ef60 printLocationMethod_1028_b12e22");
    }

    public void printLocationMethod_1028_c2acdf() {
        java.lang.System.out.println("initPac.Crecord_1028_23ef60 printLocationMethod_1028_c2acdf");
    }
}
