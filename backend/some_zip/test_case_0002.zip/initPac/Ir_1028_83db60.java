package initPac;
public interface Ir_1028_83db60 {
    void run_1028_9de9cf();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_83db60: default method");
    }
}
