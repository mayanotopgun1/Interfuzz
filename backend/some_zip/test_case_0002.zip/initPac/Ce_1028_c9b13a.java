package initPac;
public enum Ce_1028_c9b13a {

    VALUE1,
    VALUE2;

    public void printLocationMethod_1028_397462() {
        java.lang.System.out.println("initPac.Ce_1028_c9b13a printLocationMethod_1028_397462");
    }

    public void printLocationMethod_1028_5767c7() {
        java.lang.System.out.println("initPac.Ce_1028_c9b13a printLocationMethod_1028_5767c7");
    }

    public initPac.P_1028_484b58.Ir_1028_ce7e8f field_1028_0d2c84;

    initPac.P_1028_d0192f.Ce_1028_8c4a9a[] field_1028_f3247d;
}
