package initPac;
public class Cr_1028_9662f0 extends initPac.Test0002 implements initPac.P_1028_484b58.If_1028_b98fa4 {
    public int apply_1028_a7d8f9() {
        return 123123;
    }

    public void printLocationMethod_1028_e85461() {
        java.lang.System.out.println("Cr_1028_9662f0 printLocationMethod_1028_e85461");
    }

    public void printLocationMethod_1028_94fc8f() {
        java.lang.System.out.println("initPac.Cr_1028_9662f0 printLocationMethod_1028_94fc8f");
    }

    public void vMeth() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_826f43) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8e1c9d() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_992a60) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void mainTest(java.lang.String[] strArr1) {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_9f5348) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_f5b142() {
        initPac.P_1028_d0192f.Cg_1028_17a993 cg_1028_17a993_1028_c03129 = new initPac.P_1028_d0192f.Cg_1028_17a993();
        this.field_1028_2151b5 = cg_1028_17a993_1028_c03129;
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_371917) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_392794() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_a11792) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_77a29a() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_992ba6) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void vMeth1(long l) {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_89736a) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_b73e3b() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_36d499) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public int iMeth() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_500be0) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int int_1028_2401ad = 72;
        return int_1028_2401ad;
    }

    public void printLocationMethod_1028_4f9359() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_f45ba3) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8acf75() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_83cd11) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_eaed59() {
        try {
            printLocationMethod_1028_94fc8f();
        } catch (java.lang.Exception e1028_5f88ee) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_94fc8f");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_e35191() {
        java.lang.System.out.println("initPac.Cr_1028_9662f0 printLocationMethod_1028_e35191");
    }

    public void printLocationMethod_1028_26fb7e() {
        java.lang.System.out.println("initPac.Cr_1028_9662f0 printLocationMethod_1028_26fb7e");
    }

    public initPac.Ir_1028_5b6001 field_1028_4bbb79;

    public initPac.P_1028_d0192f.Cg_1028_17a993 field_1028_2151b5;
}
