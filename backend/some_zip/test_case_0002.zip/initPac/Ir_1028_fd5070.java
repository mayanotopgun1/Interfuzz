package initPac;
public interface Ir_1028_fd5070 {
    void run_1028_4b740b();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_fd5070: default method");
    }
}
