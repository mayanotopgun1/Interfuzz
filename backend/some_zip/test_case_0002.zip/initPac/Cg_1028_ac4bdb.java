package initPac;
class Cg_1028_ac4bdb<T> {
    java.util.List<T> items_1028_a92abb = new java.util.ArrayList<T>();

    public void addItem_1028_2e74bd(T item) {
        this.items_1028_a92abb.add(item);
    }

    public T getItem_1028_063da1(int index) {
        if (this.items_1028_a92abb.isEmpty()) {
            return null;
        }
        int size = this.items_1028_a92abb.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_a92abb.get(idx);
    }

    T value_1028_bbf8a0;

    public T getValue_1028_bbf8a0() {
        return this.value_1028_bbf8a0;
    }

    public void setValue_1028_bbf8a0(T value) {
        this.value_1028_bbf8a0 = value;
    }

    public void printLocationMethod_1028_b04f19() {
        java.lang.System.out.println("Cg_1028_ac4bdb printLocationMethod_1028_b04f19");
    }
}
