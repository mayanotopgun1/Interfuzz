package initPac;
class Cg_1028_92f19c<T> extends initPac.FuzzerUtils implements initPac.Ir_1028_5b6001 , initPac.P_1028_484b58.If_1028_10704f {
    public void run_1028_5490e5() {
    }

    public void run_1028_4b740b() {
    }

    java.util.List<T> items_1028_fea7b9 = new java.util.ArrayList<T>();

    public int apply_1028_274df3() {
        return 123123;
    }

    public void addItem_1028_7d6e9c(T item) {
        this.items_1028_fea7b9.add(item);
    }

    public T getItem_1028_bd0e46(int index) {
        if (this.items_1028_fea7b9.isEmpty()) {
            return null;
        }
        int size = this.items_1028_fea7b9.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_fea7b9.get(idx);
    }

    T value_1028_c387c6;

    public T getValue_1028_c387c6() {
        return this.value_1028_c387c6;
    }

    public void setValue_1028_c387c6(T value) {
        initPac.Cg_1028_92f19c cg_1028_92f19c_1028_02907f = new initPac.Cg_1028_92f19c();
        this.field_1028_47be8c = cg_1028_92f19c_1028_02907f;
        this.value_1028_c387c6 = value;
    }

    public void printLocationMethod_1028_b31b2b() {
        java.lang.System.out.println("Cg_1028_92f19c printLocationMethod_1028_b31b2b");
    }

    public void printLocationMethod_1028_be7f2e() {
        initPac.Ce_1028_c05091 ce_1028_c05091_1028_1b8c7f = initPac.Ce_1028_c05091.VALUE1;
        this.field_1028_f51835 = ce_1028_c05091_1028_1b8c7f;
        java.lang.System.out.println("initPac.Cg_1028_92f19c printLocationMethod_1028_be7f2e");
    }

    initPac.Cg_1028_92f19c field_1028_47be8c;

    initPac.Ce_1028_c05091 field_1028_f51835;

    public initPac.If_1028_ee5280[] field_1028_c84b28;

    public void printLocationMethod_1028_6624e8() {
        java.lang.System.out.println("initPac.Cg_1028_92f19c printLocationMethod_1028_6624e8");
    }

    public void printLocationMethod_1028_8e1c9d() {
        try {
            initPac.Cg_1028_92f19c<java.lang.String> cg_1028_92f19c_1028_cf7839 = new initPac.Cg_1028_92f19c<java.lang.String>();
            cg_1028_92f19c_1028_cf7839.printLocationMethod_1028_6624e8();
        } catch (java.lang.Exception e1028_cf9d23) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_6624e8");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_f5b142() {
        try {
            initPac.Cg_1028_92f19c<java.lang.Integer[]> cg_1028_92f19c_1028_243992 = new initPac.Cg_1028_92f19c<java.lang.Integer[]>();
            cg_1028_92f19c_1028_243992.printLocationMethod_1028_6624e8();
        } catch (java.lang.Exception e1028_505ece) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_6624e8");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_392794() {
        try {
            initPac.Cg_1028_92f19c<java.lang.Short> cg_1028_92f19c_1028_037194 = new initPac.Cg_1028_92f19c<java.lang.Short>();
            cg_1028_92f19c_1028_037194.printLocationMethod_1028_6624e8();
        } catch (java.lang.Exception e1028_ecd5a7) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_6624e8");
        }
        java.lang.String string_1028_6ec4a9 = "123456abc";
        int int_1028_606d64 = 61;
        initPac.P_1028_484b58.Crecord_1028_241ed6 crecord_1028_241ed6_1028_09979c = new initPac.P_1028_484b58.Crecord_1028_241ed6(string_1028_6ec4a9, int_1028_606d64);
        this.field_1028_ca8c6c = crecord_1028_241ed6_1028_09979c;
        int a = 123;
    }

    public void printLocationMethod_1028_4f9359() {
        try {
            initPac.Cg_1028_92f19c<java.lang.Short[]> cg_1028_92f19c_1028_562720 = new initPac.Cg_1028_92f19c<java.lang.Short[]>();
            cg_1028_92f19c_1028_562720.printLocationMethod_1028_6624e8();
        } catch (java.lang.Exception e1028_9d36d2) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_6624e8");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8acf75() {
        try {
            initPac.Cg_1028_92f19c<java.lang.Byte> cg_1028_92f19c_1028_88f738 = new initPac.Cg_1028_92f19c<java.lang.Byte>();
            cg_1028_92f19c_1028_88f738.printLocationMethod_1028_6624e8();
        } catch (java.lang.Exception e1028_0a7f2f) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_6624e8");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_eaed59() {
        try {
            initPac.Cg_1028_92f19c<java.lang.String[]> cg_1028_92f19c_1028_55f6aa = new initPac.Cg_1028_92f19c<java.lang.String[]>();
            cg_1028_92f19c_1028_55f6aa.printLocationMethod_1028_6624e8();
        } catch (java.lang.Exception e1028_350939) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_6624e8");
        }
        int a = 123;
    }

    public boolean[] field_1028_d00068;

    public void printLocationMethod_1028_4eb8e4() {
        java.lang.System.out.println("initPac.Cg_1028_92f19c printLocationMethod_1028_4eb8e4");
    }

    public void defaultMethod() {
        initPac.Ir_1028_5b6001.super.defaultMethod();
    }

    public initPac.If_1028_d4049a field_1028_ddcc9a;

    initPac.P_1028_484b58.Crecord_1028_241ed6 field_1028_ca8c6c;
}
