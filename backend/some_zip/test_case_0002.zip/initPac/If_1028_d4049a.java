package initPac;
public interface If_1028_d4049a {
    abstract int apply_1028_fcef2a();
}
