package initPac;
public interface If_1028_356365 {
    abstract int apply_1028_c8c6e8();
}
