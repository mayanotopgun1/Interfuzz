package initPac;
public class FuzzerUtils {
    public static java.io.PrintStream out = java.lang.System.out;

    public static java.util.Random random = new java.util.Random(1);

    public static long seed = 1L;

    public static int UnknownZero = 0;

    public static void seed(long seed) {
        initPac.FuzzerUtils.random = new java.util.Random(seed);
        initPac.FuzzerUtils.seed = seed;
    }

    public static int nextInt() {
        return initPac.FuzzerUtils.random.nextInt();
    }

    public static long nextLong() {
        return initPac.FuzzerUtils.random.nextLong();
    }

    public static float nextFloat() {
        return initPac.FuzzerUtils.random.nextFloat();
    }

    public static double nextDouble() {
        return initPac.FuzzerUtils.random.nextDouble();
    }

    public static boolean nextBoolean() {
        return initPac.FuzzerUtils.random.nextBoolean();
    }

    public static byte nextByte() {
        return ((byte) (initPac.FuzzerUtils.random.nextInt()));
    }

    public static short nextShort() {
        return ((short) (initPac.FuzzerUtils.random.nextInt()));
    }

    public static char nextChar() {
        return ((char) (initPac.FuzzerUtils.random.nextInt()));
    }

    public static void init(boolean[] a, boolean seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = ((j % 2) == 0) ? seed : (j % 3) == 0;
        }
    }

    public static void init(boolean[][] a, boolean seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(long[] a, long seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = ((j % 2) == 0) ? seed + j : seed - j;
        }
    }

    public static void init(long[][] a, long seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(int[] a, int seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = ((j % 2) == 0) ? seed + j : seed - j;
        }
    }

    public static void init(int[][] a, int seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(short[] a, short seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = ((short) (((j % 2) == 0) ? seed + j : seed - j));
        }
    }

    public static void init(short[][] a, short seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(char[] a, char seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = ((char) (((j % 2) == 0) ? seed + j : seed - j));
        }
    }

    public static void init(char[][] a, char seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(byte[] a, byte seed) {
        try {
            java.lang.String string_1028_bf6684 = "123456abc";
            int int_1028_6f3707 = 16;
            initPac.P_1028_484b58.Crecord_1028_98f019 crecord_1028_98f019_1028_6532a9 = new initPac.P_1028_484b58.Crecord_1028_98f019(string_1028_bf6684, int_1028_6f3707);
            crecord_1028_98f019_1028_6532a9.printInfo();
        } catch (java.lang.Exception e1028_ef8b8d) {
            java.lang.System.out.println("Method Invoke Exception: printInfo");
        }
        try {
            java.lang.String string_1028_e1c263 = "123456abc";
            int int_1028_d28ba6 = initPac.FuzzerUtils.UnknownZero;
            initPac.Crecord_1028_880872 crecord_1028_880872_1028_b173a5 = new initPac.Crecord_1028_880872(string_1028_e1c263, int_1028_d28ba6);
            crecord_1028_880872_1028_b173a5.age();
        } catch (java.lang.Exception e1028_d2a29d) {
            java.lang.System.out.println("Method Invoke Exception: age");
        }
        for (int j = 0; j < a.length; j++) {
            a[j] = ((byte) (((j % 2) == 0) ? seed + j : seed - j));
        }
    }

    public static void init(byte[][] a, byte seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(double[] a, double seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = ((j % 2) == 0) ? seed + j : seed - j;
        }
    }

    public static void init(double[][] a, double seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(float[] a, float seed) {
        for (int j = 0; j < a.length; j++) {
            a[j] = ((j % 2) == 0) ? seed + j : seed - j;
        }
    }

    public static void init(float[][] a, float seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(java.lang.Object[][] a, java.lang.Object seed) {
        for (int j = 0; j < a.length; j++) {
            initPac.FuzzerUtils.init(a[j], seed);
        }
    }

    public static void init(java.lang.Object[] a, java.lang.Object seed) {
        for (int j = 0; j < a.length; j++)
            try {
                a[j] = seed.getClass().newInstance();
            } catch (java.lang.Exception ex) {
                a[j] = seed;
            }

    }

    public static long checkSum(boolean[] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += (a[j]) ? j + 1 : 0;
        }
        return sum;
    }

    public static long checkSum(boolean[][] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static long checkSum(long[] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += (a[j] / (j + 1)) + (a[j] % (j + 1));
        }
        return sum;
    }

    public static long checkSum(long[][] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static long checkSum(int[] a) {
        try {
            java.lang.String string_1028_8ae0cc = "123456abc";
            int int_1028_a29554 = 98;
            initPac.P_1028_484b58.Crecord_1028_98f019 crecord_1028_98f019_1028_e63c40 = new initPac.P_1028_484b58.Crecord_1028_98f019(string_1028_8ae0cc, int_1028_a29554);
            crecord_1028_98f019_1028_e63c40.age();
        } catch (java.lang.Exception e1028_716fe3) {
            java.lang.System.out.println("Method Invoke Exception: age");
        }
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += (a[j] / (j + 1)) + (a[j] % (j + 1));
        }
        return sum;
    }

    public static long checkSum(int[][] a) {
        try {
            java.lang.String string_1028_1c3e76 = "123456abc";
            int int_1028_cf90fa = 35;
            initPac.Crecord_1028_23ef60 crecord_1028_23ef60_1028_180550 = new initPac.Crecord_1028_23ef60(string_1028_1c3e76, int_1028_cf90fa);
            crecord_1028_23ef60_1028_180550.printLocationMethod_1028_b12e22();
        } catch (java.lang.Exception e1028_1f02cd) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b12e22");
        }
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        try {
            java.lang.String string_1028_576048 = "123456abc";
            int int_1028_3534b2 = initPac.FuzzerUtils.UnknownZero;
            initPac.Crecord_1028_880872 crecord_1028_880872_1028_2deeb8 = new initPac.Crecord_1028_880872(string_1028_576048, int_1028_3534b2);
            crecord_1028_880872_1028_2deeb8.printInfo();
        } catch (java.lang.Exception e1028_1eeee3) {
            java.lang.System.out.println("Method Invoke Exception: printInfo");
        }
        return sum;
    }

    public static long checkSum(short[] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += ((short) ((a[j] / (j + 1)) + (a[j] % (j + 1))));
        }
        return sum;
    }

    public static long checkSum(short[][] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static long checkSum(char[] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += ((char) ((a[j] / (j + 1)) + (a[j] % (j + 1))));
        }
        return sum;
    }

    public static long checkSum(char[][] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static long checkSum(byte[] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += ((byte) ((a[j] / (j + 1)) + (a[j] % (j + 1))));
        }
        return sum;
    }

    public static long checkSum(byte[][] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static double checkSum(double[] a) {
        double sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += (a[j] / (j + 1)) + (a[j] % (j + 1));
        }
        return sum;
    }

    public static double checkSum(double[][] a) {
        double sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static double checkSum(float[] a) {
        double sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += (a[j] / (j + 1)) + (a[j] % (j + 1));
        }
        return sum;
    }

    public static double checkSum(float[][] a) {
        double sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static long checkSum(java.lang.Object[][] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]);
        }
        return sum;
    }

    public static long checkSum(java.lang.Object[] a) {
        long sum = 0;
        for (int j = 0; j < a.length; j++) {
            sum += initPac.FuzzerUtils.checkSum(a[j]) * java.lang.Math.pow(2, j);
        }
        return sum;
    }

    public static long checkSum(java.lang.Object a) {
        if (a == null)
            return 0L;

        return ((long) (a.getClass().getCanonicalName().length()));
    }

    public static byte[] byte1array(int sz, byte seed) {
        byte[] ret = new byte[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static byte[][] byte2array(int sz, byte seed) {
        byte[][] ret = new byte[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static short[] short1array(int sz, short seed) {
        short[] ret = new short[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static short[][] short2array(int sz, short seed) {
        short[][] ret = new short[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static int[] int1array(int sz, int seed) {
        int[] ret = new int[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static int[][] int2array(int sz, int seed) {
        int[][] ret = new int[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static long[] long1array(int sz, long seed) {
        long[] ret = new long[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static long[][] long2array(int sz, long seed) {
        long[][] ret = new long[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static float[] float1array(int sz, float seed) {
        float[] ret = new float[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static float[][] float2array(int sz, float seed) {
        float[][] ret = new float[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static double[] double1array(int sz, double seed) {
        double[] ret = new double[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static double[][] double2array(int sz, double seed) {
        double[][] ret = new double[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static char[] char1array(int sz, char seed) {
        char[] ret = new char[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static char[][] char2array(int sz, char seed) {
        char[][] ret = new char[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static java.lang.Object[] Object1array(int sz, java.lang.Object seed) {
        java.lang.Object[] ret = new java.lang.Object[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static java.lang.Object[][] Object2array(int sz, java.lang.Object seed) {
        java.lang.Object[][] ret = new java.lang.Object[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static boolean[] boolean1array(int sz, boolean seed) {
        boolean[] ret = new boolean[sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static boolean[][] boolean2array(int sz, boolean seed) {
        boolean[][] ret = new boolean[sz][sz];
        initPac.FuzzerUtils.init(ret, seed);
        return ret;
    }

    public static java.util.concurrent.atomic.AtomicLong runningThreads = new java.util.concurrent.atomic.AtomicLong(0);

    public static synchronized void runThread(java.lang.Runnable r) {
        final java.lang.Thread t = new java.lang.Thread(r);
        t.start();
        initPac.FuzzerUtils.runningThreads.incrementAndGet();
        java.lang.Thread t1 = new java.lang.Thread(new java.lang.Runnable() {
            public void run() {
                try {
                    t.join();
                    initPac.FuzzerUtils.runningThreads.decrementAndGet();
                } catch (java.lang.InterruptedException e) {
                }
            }
        });
        t1.start();
    }

    public static void joinThreads() {
        while (initPac.FuzzerUtils.runningThreads.get() > 0) {
            try {
                java.lang.Thread.sleep(1000);
            } catch (java.lang.InterruptedException e) {
            }
        } 
    }

    public void printLocationMethod_1028_8e1c9d() {
        java.lang.System.out.println("initPac.FuzzerUtils printLocationMethod_1028_8e1c9d");
    }

    public void printLocationMethod_1028_8acf75() {
        java.lang.System.out.println("initPac.FuzzerUtils printLocationMethod_1028_8acf75");
    }

    public void printLocationMethod_1028_eaed59() {
        java.lang.System.out.println("initPac.FuzzerUtils printLocationMethod_1028_eaed59");
    }

    public initPac.Ir_1028_08404c field_1028_6181f2;

    public void printLocationMethod_1028_f5b142() {
        java.lang.System.out.println("initPac.FuzzerUtils printLocationMethod_1028_f5b142");
    }

    public void printLocationMethod_1028_392794() {
        initPac.FuzzerUtils fuzzerUtils_1028_c539b5 = new initPac.FuzzerUtils();
        this.field_1028_c2210b = fuzzerUtils_1028_c539b5;
        java.lang.System.out.println("initPac.FuzzerUtils printLocationMethod_1028_392794");
    }

    public void printLocationMethod_1028_4f9359() {
        java.lang.System.out.println("initPac.FuzzerUtils printLocationMethod_1028_4f9359");
    }

    public initPac.FuzzerUtils field_1028_c2210b;

    public initPac.Ce_1028_c9b13a field_1028_3407a1;
}
