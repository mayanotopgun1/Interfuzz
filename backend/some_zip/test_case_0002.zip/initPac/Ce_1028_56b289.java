package initPac;
public enum Ce_1028_56b289 {

    VALUE1,
    VALUE2;
}
