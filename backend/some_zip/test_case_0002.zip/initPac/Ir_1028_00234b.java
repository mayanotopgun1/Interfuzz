package initPac;
public interface Ir_1028_00234b {
    void run_1028_e7d8c5();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_00234b: default method");
    }
}
