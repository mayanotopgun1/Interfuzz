package initPac;
public enum Ce_1028_9bb2c0 {

    VALUE1,
    VALUE2;

    public initPac.P_1028_484b58.If_1028_ddef0f field_1028_ff3b66;
}
