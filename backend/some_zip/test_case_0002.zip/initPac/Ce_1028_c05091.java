package initPac;
public enum Ce_1028_c05091 {

    VALUE1,
    VALUE2;

    public void printLocationMethod_1028_2b73ed() {
        initPac.Ce_1028_3589b5 ce_1028_3589b5_1028_cca150 = initPac.Ce_1028_3589b5.VALUE1;
        this.field_1028_b4346e = ce_1028_3589b5_1028_cca150;
        java.lang.System.out.println("initPac.Ce_1028_c05091 printLocationMethod_1028_2b73ed");
    }

    boolean[] field_1028_393e12;

    initPac.Ce_1028_3589b5 field_1028_b4346e;

    public double field_1028_0cddc8 = 0.47990491103402055;
}
