package initPac;
public interface Ir_1028_c612a2 {
    void run_1028_663a98();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_c612a2: default method");
    }
}
