package initPac;
public enum Ce_1028_dc8c77 {

    VALUE1,
    VALUE2;

    public void printLocationMethod_1028_a2d701() {
        java.lang.System.out.println("initPac.Ce_1028_dc8c77 printLocationMethod_1028_a2d701");
    }
}
