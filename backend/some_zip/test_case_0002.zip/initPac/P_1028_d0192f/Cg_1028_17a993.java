package initPac.P_1028_d0192f;
public class Cg_1028_17a993<T> {
    java.util.List<T> items_1028_4aefc7 = new java.util.ArrayList<T>();

    public void addItem_1028_f4bed2(T item) {
        this.items_1028_4aefc7.add(item);
    }

    public T getItem_1028_68c4d9(int index) {
        if (this.items_1028_4aefc7.isEmpty()) {
            return null;
        }
        int size = this.items_1028_4aefc7.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_4aefc7.get(idx);
    }

    T value_1028_490547;

    public T getValue_1028_490547() {
        return this.value_1028_490547;
    }

    public void setValue_1028_490547(T value) {
        this.value_1028_490547 = value;
    }

    public void printLocationMethod_1028_660ecb() {
        java.lang.System.out.println("Cg_1028_17a993 printLocationMethod_1028_660ecb");
    }

    public int[] field_1028_7f5294;
}
