package initPac.P_1028_d0192f;
public class Cr_1028_718a9c {
    public void printLocationMethod_1028_a8b842() {
        java.lang.System.out.println("Cr_1028_718a9c printLocationMethod_1028_a8b842");
    }
}
