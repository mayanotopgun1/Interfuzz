package initPac.P_1028_d0192f;
public record Crecord_1028_4f4190(java.lang.String name, int age) {
    public void printLocationMethod_1028_580571() {
        java.lang.System.out.println("Crecord_1028_4f4190 printLocationMethod_1028_580571");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
