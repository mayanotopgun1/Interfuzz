package initPac.P_1028_d0192f;
public interface Ir_1028_d63472 {
    void run_1028_039b5f();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_d63472: default method");
    }
}
