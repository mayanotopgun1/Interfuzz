package initPac.P_1028_d0192f;
class Cg_1028_bf8dbe<T> {
    java.util.List<T> items_1028_86200e = new java.util.ArrayList<T>();

    public void addItem_1028_a649c8(T item) {
        this.items_1028_86200e.add(item);
    }

    public T getItem_1028_4103e3(int index) {
        if (this.items_1028_86200e.isEmpty()) {
            return null;
        }
        int size = this.items_1028_86200e.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_86200e.get(idx);
    }

    T value_1028_8f013a;

    public T getValue_1028_8f013a() {
        return this.value_1028_8f013a;
    }

    public void setValue_1028_8f013a(T value) {
        this.value_1028_8f013a = value;
    }

    public void printLocationMethod_1028_82242d() {
        java.lang.System.out.println("Cg_1028_bf8dbe printLocationMethod_1028_82242d");
    }
}
