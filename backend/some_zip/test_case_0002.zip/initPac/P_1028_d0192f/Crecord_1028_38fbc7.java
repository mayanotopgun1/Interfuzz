package initPac.P_1028_d0192f;
public record Crecord_1028_38fbc7(java.lang.String name, int age) {
    public void printLocationMethod_1028_06a4a3() {
        java.lang.System.out.println("Crecord_1028_38fbc7 printLocationMethod_1028_06a4a3");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
