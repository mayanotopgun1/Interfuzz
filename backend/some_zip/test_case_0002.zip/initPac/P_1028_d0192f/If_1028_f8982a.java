package initPac.P_1028_d0192f;
public interface If_1028_f8982a {
    abstract int apply_1028_7abdfb();
}
