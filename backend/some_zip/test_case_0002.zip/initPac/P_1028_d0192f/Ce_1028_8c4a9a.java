package initPac.P_1028_d0192f;
public enum Ce_1028_8c4a9a {

    VALUE1,
    VALUE2;
}
