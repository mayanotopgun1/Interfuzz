package initPac.P_1028_d0192f;
public interface If_1028_c14448 {
    abstract int apply_1028_7cc1a0();
}
