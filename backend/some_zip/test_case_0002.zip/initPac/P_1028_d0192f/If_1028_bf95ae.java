package initPac.P_1028_d0192f;
public interface If_1028_bf95ae {
    abstract int apply_1028_6649a0();
}
