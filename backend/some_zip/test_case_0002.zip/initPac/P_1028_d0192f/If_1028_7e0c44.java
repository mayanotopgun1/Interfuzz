package initPac.P_1028_d0192f;
public interface If_1028_7e0c44 extends initPac.Ir_1028_83db60 {
    abstract int apply_1028_40721b();
}
