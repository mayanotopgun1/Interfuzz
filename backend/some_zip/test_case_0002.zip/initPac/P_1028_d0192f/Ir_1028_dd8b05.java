package initPac.P_1028_d0192f;
public interface Ir_1028_dd8b05 {
    void run_1028_7f1eb9();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_dd8b05: default method");
    }
}
