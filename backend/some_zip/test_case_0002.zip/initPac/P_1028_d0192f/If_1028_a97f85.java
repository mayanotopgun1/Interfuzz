package initPac.P_1028_d0192f;
public interface If_1028_a97f85 {
    abstract int apply_1028_7083cd();
}
