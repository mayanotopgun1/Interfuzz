package initPac;
public enum Ce_1028_3589b5 {

    VALUE1,
    VALUE2;
}
