package initPac;
class Cg_1028_b97046<T> implements initPac.P_1028_484b58.Ir_1028_0841e1 {
    java.util.List<T> items_1028_8ffed2 = new java.util.ArrayList<T>();

    public void run_1028_8bc7fb() {
    }

    public void addItem_1028_8d892f(T item) {
        this.items_1028_8ffed2.add(item);
    }

    public T getItem_1028_71b519(int index) {
        if (this.items_1028_8ffed2.isEmpty()) {
            return null;
        }
        int size = this.items_1028_8ffed2.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_8ffed2.get(idx);
    }

    T value_1028_d852eb;

    public T getValue_1028_d852eb() {
        return this.value_1028_d852eb;
    }

    public void setValue_1028_d852eb(T value) {
        this.value_1028_d852eb = value;
    }

    public void printLocationMethod_1028_902e92() {
        java.lang.System.out.println("Cg_1028_b97046 printLocationMethod_1028_902e92");
    }
}
