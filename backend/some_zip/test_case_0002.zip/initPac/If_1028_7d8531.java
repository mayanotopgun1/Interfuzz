package initPac;
public interface If_1028_7d8531 {
    abstract int apply_1028_5c5f96();
}
