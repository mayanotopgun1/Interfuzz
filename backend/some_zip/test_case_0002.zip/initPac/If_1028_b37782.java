package initPac;
public interface If_1028_b37782 {
    abstract int apply_1028_db620a();
}
