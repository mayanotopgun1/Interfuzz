package initPac.P_1028_a42518;
public class Cg_1028_67a245<T> extends initPac.P_1028_a42518.Cr_1028_9a0881 implements initPac.P_1028_484b58.Ir_1028_ce7e8f , initPac.Ir_1028_62ca86 {
    public void run_1028_83f6bb() {
    }

    public void run_1028_ac493e() {
    }

    java.util.List<T> items_1028_180665 = new java.util.ArrayList<T>();

    public void addItem_1028_2584a7(T item) {
        this.items_1028_180665.add(item);
    }

    public T getItem_1028_20a3c5(int index) {
        if (this.items_1028_180665.isEmpty()) {
            return null;
        }
        int size = this.items_1028_180665.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_180665.get(idx);
    }

    T value_1028_013f79;

    public T getValue_1028_013f79() {
        return this.value_1028_013f79;
    }

    public void setValue_1028_013f79(T value) {
        this.value_1028_013f79 = value;
    }

    public void printLocationMethod_1028_24729d() {
        java.lang.System.out.println("Cg_1028_67a245 printLocationMethod_1028_24729d");
    }

    public void printLocationMethod_1028_50e32a() {
        java.lang.System.out.println("initPac.P_1028_a42518.Cg_1028_67a245 printLocationMethod_1028_50e32a");
    }

    public void printLocationMethod_1028_2d253e() {
        try {
            initPac.P_1028_a42518.Cg_1028_67a245<java.lang.String[]> cg_1028_67a245_1028_786247 = new initPac.P_1028_a42518.Cg_1028_67a245<java.lang.String[]>();
            cg_1028_67a245_1028_786247.printLocationMethod_1028_50e32a();
        } catch (java.lang.Exception e1028_aa2df7) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_50e32a");
        }
        int a = 123;
    }

    public void defaultMethod() {
        initPac.P_1028_484b58.Ir_1028_ce7e8f.super.defaultMethod();
    }
}
