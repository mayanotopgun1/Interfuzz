package initPac.P_1028_a42518;
public interface Ir_1028_1248e4 {
    void run_1028_794f0a();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_1248e4: default method");
    }
}
