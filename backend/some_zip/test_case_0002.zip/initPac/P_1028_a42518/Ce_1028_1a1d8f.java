package initPac.P_1028_a42518;
public enum Ce_1028_1a1d8f {

    VALUE1,
    VALUE2;

    public initPac.P_1028_484b58.If_1028_1c2da3[] field_1028_f3303b;
}
