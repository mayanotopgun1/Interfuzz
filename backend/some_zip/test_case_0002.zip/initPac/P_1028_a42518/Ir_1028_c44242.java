package initPac.P_1028_a42518;
public interface Ir_1028_c44242 {
    void run_1028_ae9cec();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_c44242: default method");
    }
}
