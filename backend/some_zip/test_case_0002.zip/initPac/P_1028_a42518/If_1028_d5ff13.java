package initPac.P_1028_a42518;
public interface If_1028_d5ff13 {
    abstract int apply_1028_cab293();
}
