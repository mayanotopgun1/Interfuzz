package initPac.P_1028_a42518;
public interface Ir_1028_09e9f7 {
    void run_1028_9d3774();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_09e9f7: default method");
    }
}
