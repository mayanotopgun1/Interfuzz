package initPac.P_1028_a42518;
public interface If_1028_a95d52 {
    abstract int apply_1028_3311fd();
}
