package initPac.P_1028_a42518;
public interface Ir_1028_539d0c {
    void run_1028_ba867d();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_539d0c: default method");
    }
}
