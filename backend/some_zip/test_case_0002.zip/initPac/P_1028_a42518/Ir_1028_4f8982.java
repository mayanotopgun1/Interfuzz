package initPac.P_1028_a42518;
public interface Ir_1028_4f8982 {
    void run_1028_fb7732();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_4f8982: default method");
    }
}
