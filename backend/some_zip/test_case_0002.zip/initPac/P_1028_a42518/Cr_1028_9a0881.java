package initPac.P_1028_a42518;
public class Cr_1028_9a0881 implements initPac.P_1028_d0192f.If_1028_a97f85 , initPac.If_1028_f6155d {
    public int apply_1028_7083cd() {
        return 123123;
    }

    public void run_1028_9de9cf() {
    }

    public void printLocationMethod_1028_2d253e() {
        java.lang.System.out.println("Cr_1028_9a0881 printLocationMethod_1028_2d253e");
    }

    public int apply_1028_da7e2b() {
        return 123123;
    }

    float field_1028_9544b3 = 0.25007594F;

    public void printLocationMethod_1028_7a8ab6() {
        java.lang.System.out.println("initPac.P_1028_a42518.Cr_1028_9a0881 printLocationMethod_1028_7a8ab6");
    }
}
