package initPac.P_1028_a42518;
public enum Ce_1028_a92877 {

    VALUE1,
    VALUE2;
}
