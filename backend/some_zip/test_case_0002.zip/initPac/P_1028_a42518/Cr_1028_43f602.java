package initPac.P_1028_a42518;
public class Cr_1028_43f602 {
    public void printLocationMethod_1028_a09e32() {
        java.lang.System.out.println("Cr_1028_43f602 printLocationMethod_1028_a09e32");
    }

    public short[] field_1028_7d81db;
}
