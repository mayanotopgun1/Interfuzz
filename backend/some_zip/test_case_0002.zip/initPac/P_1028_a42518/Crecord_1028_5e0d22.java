package initPac.P_1028_a42518;
public record Crecord_1028_5e0d22(java.lang.String name, int age) {
    public void printLocationMethod_1028_9305f5() {
        java.lang.System.out.println("Crecord_1028_5e0d22 printLocationMethod_1028_9305f5");
    }

    public void printInfo() {
        initPac.Ce_1028_c05091 ce_1028_c05091_1028_3615bb = initPac.Ce_1028_c05091.VALUE2;
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }

    public void printLocationMethod_1028_5690c6() {
        java.lang.System.out.println("initPac.P_1028_a42518.Crecord_1028_5e0d22 printLocationMethod_1028_5690c6");
    }
}
