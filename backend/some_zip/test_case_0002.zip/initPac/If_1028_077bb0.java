package initPac;
public interface If_1028_077bb0 {
    abstract int apply_1028_fb4da6();
}
