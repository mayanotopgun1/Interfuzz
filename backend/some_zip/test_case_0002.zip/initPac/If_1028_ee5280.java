package initPac;
public interface If_1028_ee5280 extends initPac.If_1028_7d8531 {
    abstract int apply_1028_10195d();
}
