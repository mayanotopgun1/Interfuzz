package initPac;
public interface Ir_1028_743fb9 extends initPac.P_1028_484b58.If_1028_0d6cef {
    void run_1028_3dba88();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_743fb9: default method");
    }
}
