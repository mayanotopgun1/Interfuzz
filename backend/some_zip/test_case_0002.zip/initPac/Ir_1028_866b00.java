package initPac;
public interface Ir_1028_866b00 {
    void run_1028_610f9e();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_866b00: default method");
    }
}
