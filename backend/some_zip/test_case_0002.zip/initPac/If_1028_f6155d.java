package initPac;
public interface If_1028_f6155d extends initPac.Ir_1028_83db60 {
    abstract int apply_1028_da7e2b();
}
