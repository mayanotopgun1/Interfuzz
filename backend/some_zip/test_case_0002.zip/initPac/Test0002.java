package initPac;
public class Test0002 extends initPac.FuzzerUtils implements initPac.P_1028_484b58.If_1028_64698a , initPac.If_1028_b37782 {
    public int apply_1028_5ae092() {
        return 123123;
    }

    public int apply_1028_db620a() {
        return 123123;
    }

    public final int N = 400;

    public long instanceCount = 2805714848L;

    public short sFld = 30393;

    public byte byFld = -48;

    public volatile boolean bFld = true;

    public byte[] byArrFld = new byte[N];

    public long vMeth_check_sum = 0;

    public long iMeth_check_sum = 0;

    public long vMeth1_check_sum = 0;

    public void vMeth1(long l) {
        double d = 0.46924;
        initPac.Test0002 test0002_1028_c06c9c = new initPac.Test0002();
        this.field_1028_53cbf3 = test0002_1028_c06c9c;
        int i4 = 41637;
        int i5 = -11;
        int i6 = 9;
        int i7 = -44;
        try {
            java.lang.String string_1028_c27a06 = "123456abc";
            int int_1028_0c17a7 = i7;
            initPac.P_1028_484b58.Crecord_1028_98f019 crecord_1028_98f019_1028_220486 = new initPac.P_1028_484b58.Crecord_1028_98f019(string_1028_c27a06, int_1028_0c17a7);
            crecord_1028_98f019_1028_220486.printLocationMethod_1028_167134();
        } catch (java.lang.Exception e1028_0770e1) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_167134");
        }
        int i8 = 204;
        int[] iArr = new int[N];
        long l1 = -2304894751L;
        boolean b1 = false;
        byte[] byArr = new byte[N];
        initPac.FuzzerUtils.init(byArr, ((byte) (60)));
        initPac.FuzzerUtils.init(iArr, 766);
        for (d = 12; d < 15; d++) {
            i4 = 52490;
            for (l1 = 1; l1 < 4; ++l1) {
                byArr[((int) (l1 + 1))] = ((byte) (l1));
                sFld >>>= ((short) (l1));
                i4 = i4;
                i6 = 1;
                do {
                    i5 -= i4;
                } while ((++i6) < 2 );
                iArr[((int) (l1))] |= i4;
                i5 >>= i4;
                i5 += ((int) (l1 * l1));
            }
            i4 -= ((int) (d));
            for (i7 = 1; i7 < 4; i7 += 2) {
                i5 -= 143;
                if (b1)
                    break;

            }
        }
        vMeth1_check_sum += (((((((((l + java.lang.Double.doubleToLongBits(d)) + i4) + l1) + i5) + i6) + i7) + i8) + (b1 ? 1 : 0)) + initPac.FuzzerUtils.checkSum(byArr)) + initPac.FuzzerUtils.checkSum(iArr);
    }

    public int iMeth() {
        int i1 = -2;
        int i2 = -196;
        int i3 = -16;
        int i9 = -5;
        int i10 = 34692;
        int i11 = 168;
        float f = -1.366F;
        i1 = 292;
        while ((i1 -= 3) > 0) {
            if (i1 != 0) {
            }
            for (i2 = i1; i2 < 16; ++i2) {
                boolean b = false;
                if (b)
                    break;

                vMeth1(instanceCount);
                i3 |= i2;
                if (b)
                    break;

            }
            instanceCount += ((i1 * i2) + i1) - sFld;
            i9 = 1;
            while ((++i9) < 16) {
                for (i10 = 1; i10 < 4; i10++) {
                    f += ((long) (i10)) ^ ((long) (i2));
                    i11 = sFld;
                    sFld = ((short) (i11));
                    i11 <<= -83;
                    f -= i1;
                }
            } 
        } 
        long meth_res = (((((i1 + i2) + i3) + i9) + i10) + i11) + java.lang.Float.floatToIntBits(f);
        iMeth_check_sum += meth_res;
        try {
            java.lang.String string_1028_755159 = "123456abc";
            int int_1028_b4d94a = i11;
            initPac.Crecord_1028_23ef60 crecord_1028_23ef60_1028_1b44cc = new initPac.Crecord_1028_23ef60(string_1028_755159, int_1028_b4d94a);
            crecord_1028_23ef60_1028_1b44cc.name();
        } catch (java.lang.Exception e1028_0ca075) {
            java.lang.System.out.println("Method Invoke Exception: name");
        }
        return ((int) (meth_res));
    }

    public void vMeth() {
        int i = -63;
        i *= iMeth();
        try {
            initPac.Cg_1028_92f19c<java.lang.Short> cg_1028_92f19c_1028_a01e3b = new initPac.Cg_1028_92f19c<java.lang.Short>();
            cg_1028_92f19c_1028_a01e3b.printLocationMethod_1028_b31b2b();
        } catch (java.lang.Exception e1028_055ec5) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b31b2b");
        }
        byFld = ((byte) (instanceCount));
        i += i;
        vMeth_check_sum += i;
    }

    public void mainTest(java.lang.String[] strArr1) {
        int i12 = -15987;
        int i13 = 6;
        int i14 = 0;
        int i15 = -20743;
        int i16 = -123;
        int i17 = 61475;
        int i18 = -73;
        int[][] iArr1 = new int[N][N];
        float f1 = 0.873F;
        float f2 = 2.386F;
        long l2 = 117L;
        byte by = -27;
        double d1 = -82.58118;
        initPac.FuzzerUtils.init(iArr1, -6);
        vMeth();
        for (i12 = 4; i12 < 7; i12++) {
            i14 = 1;
            do {
                if (bFld) {
                    iArr1 = iArr1;
                    try {
                        i13 = i12 % 20;
                        i13 = iArr1[i14 + 1][i14 + 1] / i13;
                        i13 = iArr1[i14][i14] / i14;
                    } catch (java.lang.ArithmeticException a_e) {
                    }
                } else if (bFld) {
                    instanceCount += i14;
                }
                for (f1 = i14; f1 < 4; ++f1) {
                    try {
                        iArr1[((int) (f1))][i14 + 1] = (-3) % i13;
                        iArr1[i12 + 1][i14] = (-185) / i12;
                        iArr1[i14 + 1][((int) (f1 + 1))] = i15 / iArr1[i14 + 1][i14];
                    } catch (java.lang.ArithmeticException a_e) {
                    }
                    iArr1[((int) (f1 - 1))][i12] = i14;
                    i13 += ((int) (f1));
                    i13 += i15;
                    i13 += ((int) (f1));
                    i15 += ((int) (((f1 * i13) + i15) - i12));
                    f2 = f2;
                }
            } while ((i14 += 3) < 155 );
            i13 += i12;
            byFld += ((byte) (i12));
            sFld += ((short) ((-6037086024951693277L) + (i12 * i12)));
            for (l2 = 9; l2 < 12; ++l2) {
                try {
                    i16 = 225 % i16;
                    i15 = i14 % (-253);
                    i16 = i12 % 56617;
                } catch (java.lang.ArithmeticException a_e) {
                }
                try {
                    i15 = 39211 / i15;
                    i16 = iArr1[((int) (l2))][i12 - 1] / iArr1[((int) (l2))][((int) (l2 + 1))];
                    i15 = 156 / i16;
                } catch (java.lang.ArithmeticException a_e) {
                }
                for (i17 = 2; i17 > (-1); i17 -= 2) {
                    switch ((i12 % 10) + 58) {
                        case 58 :
                            i16 = i12;
                            byArrFld[i17] = ((byte) (i12));
                            break;
                        case 59 :
                        case 60 :
                            sFld ^= ((short) (i15));
                            i16 += i18;
                            break;
                        case 61 :
                            i16 *= ((int) (instanceCount));
                            i16 = i14;
                            i13 += ((int) (f2));
                            break;
                        case 62 :
                            i18 += ((int) (instanceCount));
                            break;
                        case 63 :
                            iArr1[((int) (l2 + 1))][i12 - 1] = by;
                            break;
                        case 64 :
                            instanceCount = l2;
                            break;
                        case 65 :
                            i13 <<= ((int) (l2));
                        case 66 :
                            i18 = i17;
                        case 67 :
                            iArr1[i17][i12] &= i12;
                            break;
                        default :
                            i18 = ((int) (d1));
                    }
                }
            }
        }
        initPac.FuzzerUtils.out.println((((("i12 i13 i14 = " + i12) + ",") + i13) + ",") + i14);
        initPac.FuzzerUtils.out.println((((("f1 i15 f2 = " + java.lang.Float.floatToIntBits(f1)) + ",") + i15) + ",") + java.lang.Float.floatToIntBits(f2));
        initPac.FuzzerUtils.out.println((((("l2 i16 i17 = " + l2) + ",") + i16) + ",") + i17);
        initPac.FuzzerUtils.out.println((((("i18 by d1 = " + i18) + ",") + by) + ",") + java.lang.Double.doubleToLongBits(d1));
        initPac.FuzzerUtils.out.println("iArr1 = " + initPac.FuzzerUtils.checkSum(iArr1));
        initPac.FuzzerUtils.out.println((((("instanceCount sFld byFld = " + instanceCount) + ",") + sFld) + ",") + byFld);
        initPac.FuzzerUtils.out.println((("bFld byArrFld = " + (bFld ? 1 : 0)) + ",") + initPac.FuzzerUtils.checkSum(byArrFld));
        initPac.FuzzerUtils.out.println("vMeth1_check_sum: " + vMeth1_check_sum);
        initPac.FuzzerUtils.out.println("iMeth_check_sum: " + iMeth_check_sum);
        initPac.FuzzerUtils.out.println("vMeth_check_sum: " + vMeth_check_sum);
    }

    public static void main(java.lang.String[] strArr) {
        try {
            initPac.Cg_1028_92f19c<java.lang.Short> cg_1028_92f19c_1028_ed2aeb = new initPac.Cg_1028_92f19c<java.lang.Short>();
            java.lang.Short short_1028_638316 = ((short) (13567));
            cg_1028_92f19c_1028_ed2aeb.addItem_1028_7d6e9c(short_1028_638316);
        } catch (java.lang.Exception e1028_7a0163) {
            java.lang.System.out.println("Method Invoke Exception: addItem_1028_7d6e9c");
        }
        try {
            java.lang.String string_1028_4a5489 = "123456abc";
            int int_1028_fbf126 = 26;
            initPac.P_1028_484b58.Crecord_1028_98f019 crecord_1028_98f019_1028_749b26 = new initPac.P_1028_484b58.Crecord_1028_98f019(string_1028_4a5489, int_1028_fbf126);
            crecord_1028_98f019_1028_749b26.name();
        } catch (java.lang.Exception e1028_36d585) {
            java.lang.System.out.println("Method Invoke Exception: name");
        }
        try {
            java.lang.String string_1028_25b477 = "123456abc";
            int int_1028_d31a73 = 54;
            initPac.P_1028_484b58.Crecord_1028_98f019 crecord_1028_98f019_1028_57fd62 = new initPac.P_1028_484b58.Crecord_1028_98f019(string_1028_25b477, int_1028_d31a73);
            crecord_1028_98f019_1028_57fd62.printLocationMethod_1028_384924();
        } catch (java.lang.Exception e1028_2ce03f) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_384924");
        }
        try {
            initPac.Test0002 _instance = new initPac.Test0002();
            for (int i = 0; i < 1; i++) {
                _instance.mainTest(strArr);
            }
        } catch (java.lang.Exception ex) {
            initPac.FuzzerUtils.out.println(ex.getClass().getCanonicalName());
        }
    }

    public void printLocationMethod_1028_77a29a() {
        java.lang.System.out.println("initPac.Test0002 printLocationMethod_1028_77a29a");
    }

    long[] field_1028_7edb45;

    public initPac.If_1028_f6155d field_1028_4b651d;

    public initPac.Test0002 field_1028_53cbf3;

    public void printLocationMethod_1028_b73e3b() {
        java.lang.System.out.println("initPac.Test0002 printLocationMethod_1028_b73e3b");
    }

    public void printLocationMethod_1028_8e1c9d() {
        try {
            printLocationMethod_1028_b73e3b();
        } catch (java.lang.Exception e1028_f20538) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b73e3b");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_f5b142() {
        try {
            printLocationMethod_1028_b73e3b();
        } catch (java.lang.Exception e1028_4b14bb) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b73e3b");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_392794() {
        try {
            printLocationMethod_1028_b73e3b();
        } catch (java.lang.Exception e1028_8bdf5a) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b73e3b");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_4f9359() {
        try {
            printLocationMethod_1028_b73e3b();
        } catch (java.lang.Exception e1028_2c4dbd) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b73e3b");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_8acf75() {
        try {
            printLocationMethod_1028_b73e3b();
        } catch (java.lang.Exception e1028_de0aa4) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b73e3b");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_eaed59() {
        try {
            printLocationMethod_1028_b73e3b();
        } catch (java.lang.Exception e1028_479230) {
            java.lang.System.out.println("Method Invoke Exception: printLocationMethod_1028_b73e3b");
        }
        int a = 123;
    }

    public void printLocationMethod_1028_b6de1a() {
        java.lang.System.out.println("initPac.Test0002 printLocationMethod_1028_b6de1a");
    }

    public void printLocationMethod_1028_f1039b() {
        java.lang.System.out.println("initPac.Test0002 printLocationMethod_1028_f1039b");
    }

    public initPac.P_1028_484b58.Ir_1028_69dd0a field_1028_5f40ae;
}
