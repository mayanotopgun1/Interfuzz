package initPac;
public interface Ir_1028_5b6001 {
    void run_1028_5490e5();

    default void defaultMethod() {
        initPac.Ce_1028_c9b13a ce_1028_c9b13a_1028_0e0360 = initPac.Ce_1028_c9b13a.VALUE2;
        java.lang.System.out.println("Ir_1028_5b6001: default method");
    }
}
