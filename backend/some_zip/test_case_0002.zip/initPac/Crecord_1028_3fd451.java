package initPac;
public record Crecord_1028_3fd451(java.lang.String name, int age) {
    public void printLocationMethod_1028_24b663() {
        java.lang.System.out.println("Crecord_1028_3fd451 printLocationMethod_1028_24b663");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }

    public void printLocationMethod_1028_2ec055() {
        java.lang.System.out.println("initPac.Crecord_1028_3fd451 printLocationMethod_1028_2ec055");
    }

    public void printLocationMethod_1028_f738fb() {
        java.lang.System.out.println("initPac.Crecord_1028_3fd451 printLocationMethod_1028_f738fb");
    }

    public void printLocationMethod_1028_4039e6() {
        java.lang.System.out.println("initPac.Crecord_1028_3fd451 printLocationMethod_1028_4039e6");
    }

    public void printLocationMethod_1028_b79099() {
        java.lang.System.out.println("initPac.Crecord_1028_3fd451 printLocationMethod_1028_b79099");
    }
}
