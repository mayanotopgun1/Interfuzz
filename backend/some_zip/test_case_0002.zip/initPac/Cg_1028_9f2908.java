package initPac;
class Cg_1028_9f2908<T> {
    java.util.List<T> items_1028_7b69c2 = new java.util.ArrayList<T>();

    public void addItem_1028_a24ac6(T item) {
        this.items_1028_7b69c2.add(item);
    }

    public T getItem_1028_d17e3d(int index) {
        if (this.items_1028_7b69c2.isEmpty()) {
            return null;
        }
        int size = this.items_1028_7b69c2.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_7b69c2.get(idx);
    }

    T value_1028_6a968f;

    public T getValue_1028_6a968f() {
        return this.value_1028_6a968f;
    }

    public void setValue_1028_6a968f(T value) {
        this.value_1028_6a968f = value;
    }

    public void printLocationMethod_1028_6b8908() {
        java.lang.System.out.println("Cg_1028_9f2908 printLocationMethod_1028_6b8908");
    }
}
