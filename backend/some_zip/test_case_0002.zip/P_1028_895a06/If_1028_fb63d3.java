package P_1028_895a06;
public interface If_1028_fb63d3 {
    abstract int apply_1028_3f00c0();
}
