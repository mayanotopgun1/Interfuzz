package P_1028_895a06;
public record Crecord_1028_f2d77d(java.lang.String name, int age) {
    public void printLocationMethod_1028_a4003f() {
        java.lang.System.out.println("Crecord_1028_f2d77d printLocationMethod_1028_a4003f");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
