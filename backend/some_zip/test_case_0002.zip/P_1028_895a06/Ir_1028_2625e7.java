package P_1028_895a06;
public interface Ir_1028_2625e7 extends initPac.Ir_1028_00234b {
    void run_1028_3fa38c();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_2625e7: default method");
    }
}
