package P_1028_895a06;
public class Cg_1028_d45d11<T> {
    java.util.List<T> items_1028_b8e5c0 = new java.util.ArrayList<T>();

    public void addItem_1028_b217c0(T item) {
        this.items_1028_b8e5c0.add(item);
    }

    public T getItem_1028_1d344b(int index) {
        if (this.items_1028_b8e5c0.isEmpty()) {
            return null;
        }
        int size = this.items_1028_b8e5c0.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_b8e5c0.get(idx);
    }

    T value_1028_c8b802;

    public T getValue_1028_c8b802() {
        return this.value_1028_c8b802;
    }

    public void setValue_1028_c8b802(T value) {
        this.value_1028_c8b802 = value;
    }

    public void printLocationMethod_1028_735c8e() {
        java.lang.System.out.println("Cg_1028_d45d11 printLocationMethod_1028_735c8e");
    }
}
