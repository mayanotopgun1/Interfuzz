package P_1028_895a06;
public interface Ir_1028_a31e3a {
    void run_1028_54f4c2();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_a31e3a: default method");
    }
}
