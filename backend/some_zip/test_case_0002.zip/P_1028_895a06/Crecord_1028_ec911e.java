package P_1028_895a06;
public record Crecord_1028_ec911e(java.lang.String name, int age) {
    public void printLocationMethod_1028_a2479b() {
        java.lang.System.out.println("Crecord_1028_ec911e printLocationMethod_1028_a2479b");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }
}
