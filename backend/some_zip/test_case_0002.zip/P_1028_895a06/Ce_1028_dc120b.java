package P_1028_895a06;
public enum Ce_1028_dc120b {

    VALUE1,
    VALUE2;
}
