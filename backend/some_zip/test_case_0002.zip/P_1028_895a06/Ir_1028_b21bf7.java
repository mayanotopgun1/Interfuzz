package P_1028_895a06;
public interface Ir_1028_b21bf7 {
    void run_1028_c153be();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_b21bf7: default method");
    }
}
