package P_1028_866de1;
public enum Ce_1028_09a6d6 {

    VALUE1,
    VALUE2;
}
