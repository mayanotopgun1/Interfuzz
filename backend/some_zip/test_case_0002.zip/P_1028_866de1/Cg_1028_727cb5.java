package P_1028_866de1;
public class Cg_1028_727cb5<T> {
    java.util.List<T> items_1028_f3ca0f = new java.util.ArrayList<T>();

    public void addItem_1028_689b99(T item) {
        this.items_1028_f3ca0f.add(item);
    }

    public T getItem_1028_d27022(int index) {
        if (this.items_1028_f3ca0f.isEmpty()) {
            return null;
        }
        int size = this.items_1028_f3ca0f.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_f3ca0f.get(idx);
    }

    T value_1028_f545c9;

    public T getValue_1028_f545c9() {
        return this.value_1028_f545c9;
    }

    public void setValue_1028_f545c9(T value) {
        this.value_1028_f545c9 = value;
    }

    public void printLocationMethod_1028_063b3a() {
        java.lang.System.out.println("Cg_1028_727cb5 printLocationMethod_1028_063b3a");
    }
}
