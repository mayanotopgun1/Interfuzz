package P_1028_866de1;
public interface Ir_1028_0358c6 {
    void run_1028_410e78();

    default void defaultMethod() {
        java.lang.System.out.println("Ir_1028_0358c6: default method");
    }
}
