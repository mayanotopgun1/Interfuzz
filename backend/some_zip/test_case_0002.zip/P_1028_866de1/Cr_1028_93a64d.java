package P_1028_866de1;
public class Cr_1028_93a64d {
    public void printLocationMethod_1028_b1d6a6() {
        java.lang.System.out.println("Cr_1028_93a64d printLocationMethod_1028_b1d6a6");
    }
}
