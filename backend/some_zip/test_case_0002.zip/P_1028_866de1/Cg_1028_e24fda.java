package P_1028_866de1;
class Cg_1028_e24fda<T> {
    java.util.List<T> items_1028_2c12b4 = new java.util.ArrayList<T>();

    public void addItem_1028_693ed8(T item) {
        this.items_1028_2c12b4.add(item);
    }

    public T getItem_1028_e89e69(int index) {
        if (this.items_1028_2c12b4.isEmpty()) {
            return null;
        }
        int size = this.items_1028_2c12b4.size();
        int idx = index % size;
        if (idx < 0)
            idx += size;

        return this.items_1028_2c12b4.get(idx);
    }

    T value_1028_9256a3;

    public T getValue_1028_9256a3() {
        return this.value_1028_9256a3;
    }

    public void setValue_1028_9256a3(T value) {
        this.value_1028_9256a3 = value;
    }

    public void printLocationMethod_1028_0352da() {
        java.lang.System.out.println("Cg_1028_e24fda printLocationMethod_1028_0352da");
    }
}
