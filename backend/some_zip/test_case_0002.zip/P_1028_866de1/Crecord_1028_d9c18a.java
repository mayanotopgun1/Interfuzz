package P_1028_866de1;
public record Crecord_1028_d9c18a(java.lang.String name, int age) {
    public void printLocationMethod_1028_834fb0() {
        java.lang.System.out.println("Crecord_1028_d9c18a printLocationMethod_1028_834fb0");
    }

    public void printInfo() {
        java.lang.System.out.println((("name: " + name) + "; age: ") + age);
    }

    public void printLocationMethod_1028_9294dc() {
        java.lang.System.out.println("P_1028_866de1.Crecord_1028_d9c18a printLocationMethod_1028_9294dc");
    }
}
