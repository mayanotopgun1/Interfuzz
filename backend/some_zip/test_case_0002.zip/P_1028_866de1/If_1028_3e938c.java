package P_1028_866de1;
public interface If_1028_3e938c {
    abstract int apply_1028_d72f9c();
}
